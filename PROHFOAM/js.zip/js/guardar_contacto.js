$(document).ready(function () {
    console.log("Ready");

    $('#contact').submit(function (e){
        e.preventDefault();

        var primerNombre = $('#primer-nombre').val();
        var segundoNombre = $('#segundo-nombre').val();
        var primerApellido = $('#primer-apellido').val();
        var segundoApellido = $('#segundo-apellido').val();
        var email = $('#email').val();
        var numeroCelular = $('#numero-celular').val();
        var ciudad = $('#ciudad').val();
        var colonia = $('#colonia').val();
        var tipoCliente = $('#tipo-cliente').val();
        var calle = $('#calle').val();
        var bloque = $('#bloque').val();
        var casa = $('#casa').val();

        var informacionContacto = `primer-nombre=${primerNombre}&segundo-nombre=${segundoNombre}&primer-apellido=${primerApellido}&segundo-apellido=${segundoApellido}&email=${email}&numero-celular=${numeroCelular}&ciudad=${ciudad}&colonia=${colonia}&tipo-cliente=${tipoCliente}&calle=${calle}&bloque=${bloque}&casa=${casa}`;

        console.log(informacionContacto);

        $.ajax({
			url:'php/guardar_usuario.php',
			method: 'POST',
			data: informacionContacto,
			dataType: 'json',
			success: function (data, textStatus, jqXHR){
				if (data.status == 200) {
					alert(data.mensaje);
					window.location = 'catalogo.html'
				} else if (data.status == 501) {
					console.log(data.mensaje);
				} else {
					alert(data.mensaje);
				}
				
				console.log(data);
				console.log(textStatus);
				console.log(jqXHR);
			},
			error: function (jqXHR, textStatus, errorThrown){
				console.log(jqXHR);
				console.log(`Estado: ${textStatus}`);
				console.log(errorThrown);
			}
		});

        
    })
})