<?php
	$conectar=@mysql_conect('localhost','root','');
	if (!$conectar)
	{
		echo"Conexión no exitosa";
	}
	else {
		$base=mysql_select_db('base_proyecto');
		if(!$base)
		{
			echo"No se encontró la base de datos";
		}
	}
	$pnombre=$_POST['Primer Nombre'];
	$snombre=$_POST['Segundo Nombre'];
	$papellido=$_POST['Primer Apellido'];
	$sapellido=$_POST['Segundo Apellido'];
	$email=$_POST['Email'];
	$celular=$_POST['Celular'];
	$ciudad=$_POST['Ciudad'];
	$colonia=$_POST['Colonia'];
	$calle=$_POST['Calle'];
	$bloque=$_POST['Bloque'];
	$casa=$_POST['Casa'];
	
	$sqlpersona="INSERT INTO Persona VALUES('$pnombre','$snombre','$papellido','$sapellido)";
	$pejecutar=mysql_query(sqlpersona);
	$sqldireccion="INSERT INTO Direccion VALUES('$ciudad','$colonia','$calle','$bloque','$casa')";
	$dejecutar=mysql_query(sqldireccion);
	if(!$ejecutar){
		echo"ERROR";
	}
	else{
		echo"Datos guardados de manera correcta";
	}
?>